using UnityEngine;

namespace ProjectSundial
{
    public sealed class SundialDetonationEffect : MonoBehaviour
    {
        private const int FirePuffs = 14;
        private const int ColumnPuffs = 80;
        private const int CapPuffs = 184;
        private const int CrownPuffs = 72;
        private const int DustPuffs = 30;
        private const float AtmosphereDuration = 58f;
        private const float FireballPeakTime = 5f;
        private const float CloudHandoffStart = 6f;
        private const float CloudHandoffEnd = 16f;
        private const float VacuumDuration = 5f;

        private static readonly string[] ShaderNames =
        {
            "Sprites/Default",
            "Legacy Shaders/Particles/Alpha Blended",
            "KSP/Particles/Alpha Blended"
        };

        private CelestialBody body;
        private double latitude;
        private double longitude;
        private double altitude;
        private bool inAtmosphere;
        private float age;
        private float visualRadius;
        private float fireballRadius;
        private float cloudTopRise;

        private Light flash;
        private Transform fireballCore;
        private Material fireballMaterial;
        private Texture2D fireballTexture;
        private Mesh fireballMesh;
        private Vector3[] fireballSphere;
        private Vector3[] fireballVertices;
        private float[] fireballMottle;
        private Color32[] fireballPixels;
        private int fireballColorStep = -1;
        private SundialCloudMesh cloud;
        private SundialFireballGlow glow;
        private Material glowMaterial;
        private Texture2D glowTexture;
        private Vector4[] distribution;
        private SundialShockFront shockFront;
        private Material cloudMaterial;

        internal static void Spawn(Vector3 center, CelestialBody body, float visualRadius, float fireballRadius)
        {
            if (body == null)
                return;

            var root = new GameObject("Project Sundial detonation");
            var effect = root.AddComponent<SundialDetonationEffect>();
            effect.body = body;
            effect.latitude = body.GetLatitude(center);
            effect.longitude = body.GetLongitude(center);
            effect.altitude = body.GetAltitude(center);
            effect.inAtmosphere = body.atmosphere && effect.altitude < body.atmosphereDepth;
            effect.visualRadius = Mathf.Max(100f, visualRadius);
            effect.fireballRadius = Mathf.Max(1f, fireballRadius);
            if (effect.inAtmosphere)
                effect.cloudTopRise = (float)(0.52d * (body.atmosphereDepth - effect.altitude));
            effect.UpdateAnchor();
            effect.InitializeVisuals();
            effect.RenderFrame();
        }

        private void UpdateAnchor()
        {
            Vector3d center = body.GetWorldSurfacePosition(latitude, longitude, altitude);
            Vector3 up = (Vector3)(center - body.position).normalized;
            transform.SetPositionAndRotation((Vector3)center, Quaternion.FromToRotation(Vector3.up, up));
        }

        private void InitializeVisuals()
        {
            flash = gameObject.AddComponent<Light>();
            flash.type = LightType.Point;
            flash.color = new Color(1f, 0.94f, 0.80f);
            flash.range = Mathf.Min(12000f, visualRadius);
            flash.shadows = LightShadows.None;

            if (inAtmosphere)
                InitializeFireballCore();

            Shader shader = FindShader();
            if (shader == null)
            {
                Debug.LogWarning("[ProjectSundial] No usable transparency shader found; smoke and shock fronts are unavailable.");
                return;
            }

            cloudMaterial = new Material(shader) { mainTexture = Texture2D.whiteTexture };
            glowTexture = CreateGlowTexture();
            glowMaterial = new Material(shader) { mainTexture = glowTexture };
            glow = new SundialFireballGlow(transform, glowMaterial, FirePuffs);
            InitializeCloud();

            if (inAtmosphere)
                shockFront = new SundialShockFront(transform, cloudMaterial, body.Radius + altitude, visualRadius);
        }

        private void InitializeFireballCore()
        {
            Shader shader = Shader.Find("Unlit/Texture");
            if (shader == null || !shader.isSupported)
                shader = Shader.Find("KSP/Unlit");
            if (shader == null || !shader.isSupported)
                shader = Shader.Find("Unlit/Color");
            if (shader == null || !shader.isSupported)
            {
                Debug.LogWarning("[ProjectSundial] No usable unlit shader found for the fireball core.");
                return;
            }

            fireballMaterial = new Material(shader);
            if (fireballMaterial.HasProperty("_MainTex"))
            {
                fireballTexture = CreateFireballTexture();
                fireballMaterial.SetTexture("_MainTex", fireballTexture);
            }
            else if (fireballMaterial.HasProperty("_Color"))
            {
                fireballMaterial.SetColor("_Color", new Color(1f, 0.93f, 0.68f));
            }

            GameObject core = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            core.name = "Luminous fireball";
            core.transform.SetParent(transform, false);
            Collider collider = core.GetComponent<Collider>();
            if (collider != null)
            {
                collider.enabled = false;
                Destroy(collider);
            }

            MeshRenderer renderer = core.GetComponent<MeshRenderer>();
            renderer.sharedMaterial = fireballMaterial;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            renderer.receiveShadows = false;
            fireballCore = core.transform;
            fireballMesh = core.GetComponent<MeshFilter>().mesh;
            fireballMesh.MarkDynamic();
            fireballSphere = fireballMesh.vertices;
            fireballVertices = new Vector3[fireballSphere.Length];
        }

        private Texture2D CreateFireballTexture()
        {
            const int width = 192;
            const int height = 96;
            var texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
            fireballMottle = new float[width * height];
            fireballPixels = new Color32[width * height];
            for (int y = 0; y < height; y++)
            {
                float phi = Mathf.PI * y / (height - 1f);
                float ring = Mathf.Sin(phi);
                float sy = Mathf.Cos(phi);
                for (int x = 0; x < width; x++)
                {
                    float theta = 2f * Mathf.PI * x / (width - 1f);
                    float sx = ring * Mathf.Cos(theta);
                    float sz = ring * Mathf.Sin(theta);
                    float coarse = Mathf.PerlinNoise(5f + 3.9f * (sx + 0.4f * sy), 5f + 3.9f * sz);
                    float detail = Mathf.PerlinNoise(13f + 16f * sz, 13f + 16f * (sy + 0.3f * sx));
                    fireballMottle[y * width + x] = Mathf.Clamp01(0.70f * coarse + 0.30f * detail);
                }
            }
            texture.wrapMode = TextureWrapMode.Clamp;
            return texture;
        }

        private void AnimateFireballSurface(float cooling, float handoff)
        {
            for (int i = 0; i < fireballSphere.Length; i++)
            {
                Vector3 vertex = fireballSphere[i];
                float variation = FireballSurfaceScale(vertex, age, handoff);
                fireballVertices[i] = vertex * variation;
            }
            fireballMesh.vertices = fireballVertices;
            fireballMesh.RecalculateBounds();

            int step = Mathf.FloorToInt(age * 12f);
            if (step == fireballColorStep)
                return;
            fireballColorStep = step;

            Color edge = Color.Lerp(new Color(1f, 0.73f, 0.32f), new Color(0.83f, 0.23f, 0.055f), cooling);
            Color hottest = Color.Lerp(new Color(1f, 0.99f, 0.94f), new Color(1f, 0.66f, 0.22f), cooling);
            if (fireballTexture == null)
            {
                if (fireballMaterial.HasProperty("_Color"))
                    fireballMaterial.SetColor("_Color", hottest);
                return;
            }

            for (int i = 0; i < fireballPixels.Length; i++)
            {
                float brightness = Mathf.Clamp01(Mathf.Lerp(0.88f, 0.38f, cooling)
                    + (fireballMottle[i] - 0.48f) * Mathf.Lerp(0.75f, 1.44f, cooling));
                fireballPixels[i] = Color.Lerp(edge, hottest, brightness);
            }
            fireballTexture.SetPixels32(fireballPixels);
            fireballTexture.Apply(false, false);
        }

        private static float FireballSurfaceScale(Vector3 vertex, float time, float handoff)
        {
            float phase = time * 1.35f + vertex.y * 4f;
            float broad = Mathf.Sin(vertex.x * 13f + vertex.z * 7f - phase)
                * Mathf.Cos(vertex.y * 11f - vertex.z * 9f + phase * 0.83f);
            float small = Mathf.Sin(vertex.x * 29f - vertex.y * 24f + vertex.z * 17f + phase * 1.22f);
            float swell = Mathf.Clamp01(time / 2f) * (1f - handoff * 0.31f);
            return 1f + (0.095f * broad + 0.038f * small) * swell;
        }

        private float FireballCooling()
        {
            return Mathf.SmoothStep(0f, 1f, Mathf.Clamp01((age - 2.5f) / (CloudHandoffEnd - 2.5f)));
        }

        private float FireballCenterHeight(float radius, float capCenter, float handoff)
        {
            float lift = Mathf.SmoothStep(0.06f, 0.30f, Mathf.Clamp01(age / FireballPeakTime));
            return Mathf.Lerp(radius * lift, capCenter, handoff);
        }

        private void RenderFireballCore()
        {
            if (fireballCore == null || !fireballCore.gameObject.activeSelf)
                return;
            if (age >= CloudHandoffEnd)
            {
                fireballCore.gameObject.SetActive(false);
                return;
            }

            float radius = FireballVisualRadius();
            float handoff = FireballToCloudBlend();
            CloudCap cap = GetCloudCap();
            float rise = FireballCenterHeight(radius, cap.CenterHeight, handoff);
            float collapse = Mathf.SmoothStep(1f, 0f, Mathf.Clamp01((age - 12f) / (CloudHandoffEnd - 12f)));
            float width = Mathf.Lerp(1.80f * radius, 1.40f * cap.Radius, handoff) * collapse;
            float height = Mathf.Lerp(1.80f * radius, 0.54f * cap.Radius, handoff) * collapse;
            fireballCore.localPosition = Vector3.up * rise;
            fireballCore.localScale = new Vector3(width, height, width);
            AnimateFireballSurface(FireballCooling(), handoff);
        }

        private float FireballToCloudBlend()
        {
            return Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(
                (age - CloudHandoffStart) / (CloudHandoffEnd - CloudHandoffStart)));
        }

        private struct CloudCap
        {
            public float Top;
            public float Radius;
            public float Depth => Radius * 0.55f;
            public float CenterHeight => Top - Depth * 0.5f;
        }

        private CloudCap GetCloudCap()
        {
            float growth = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01((age - 7f) / 30f));
            float top = Mathf.Lerp(Mathf.Min(12000f, cloudTopRise), cloudTopRise, growth);
            return new CloudCap
            {
                Top = top,
                Radius = Mathf.Min(Mathf.Lerp(5800f, 14000f, growth), top * 0.44f)
            };
        }

        private float FireballVisualRadius()
        {
            float peakRadius = inAtmosphere ? fireballRadius : fireballRadius * 0.11f;
            float timeToPeak = inAtmosphere ? FireballPeakTime : 2.5f;
            float expansion = 1f - Mathf.Pow(1f - Mathf.Clamp01(age / timeToPeak), 2.4f);
            return Mathf.Lerp(peakRadius * 0.015f, peakRadius, expansion);
        }

        private static Shader FindShader()
        {
            foreach (string name in ShaderNames)
            {
                Shader shader = Shader.Find(name);
                if (shader != null && shader.isSupported)
                    return shader;
            }

            return null;
        }

        private void InitializeCloud()
        {
            int capacity = inAtmosphere ? FirePuffs + ColumnPuffs + CapPuffs + CrownPuffs + DustPuffs : FirePuffs;
            if (inAtmosphere)
                cloud = new SundialCloudMesh(transform, cloudMaterial, capacity - FirePuffs);
            distribution = new Vector4[capacity];
            var random = new System.Random(1954);
            for (int i = 0; i < capacity; i++)
            {
                float angle = (float)random.NextDouble() * 2f * Mathf.PI;
                distribution[i] = new Vector4(
                    Mathf.Cos(angle), (float)random.NextDouble(),
                    Mathf.Sin(angle), (float)random.NextDouble());
            }

        }

        private static Texture2D CreateGlowTexture()
        {
            const int size = 64;
            var texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            var colors = new Color32[size * size];

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float u = (x + 0.5f) / size;
                    float v = (y + 0.5f) / size;
                    float distance = 2f * Vector2.Distance(new Vector2(u, v), new Vector2(0.5f, 0.5f));
                    float noise = 0.58f * Mathf.PerlinNoise(9f * u, 9f * v)
                        + 0.42f * Mathf.PerlinNoise(21f * u + 5f, 21f * v);
                    float alpha = Mathf.Clamp01((1f - distance) * 3.2f)
                        * Mathf.Lerp(0.35f, 0.94f, 1f - distance) * (0.35f + 0.65f * noise);
                    byte shade = (byte)Mathf.Lerp(151f, 255f, noise);
                    colors[y * size + x] = new Color32(shade, shade, shade, (byte)(255f * alpha));
                }
            }

            texture.SetPixels32(colors);
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.Apply(false, true);
            return texture;
        }

        private void LateUpdate()
        {
            age += Time.deltaTime;
            float duration = inAtmosphere ? AtmosphereDuration : VacuumDuration;
            if (body == null || age >= duration)
            {
                Destroy(gameObject);
                return;
            }

            // Use geographic coordinates so KSP floating-origin shifts do not move the blast site.
            UpdateAnchor();
            RenderFrame();
        }

        private void RenderFrame()
        {
            if (flash == null)
                return;

            float glare = 1f - Mathf.Clamp01(age / 1.4f);
            flash.intensity = 9f * glare * glare;
            flash.enabled = glare > 0f;

            RenderFireballCore();
            if (glow == null)
                return;

            var flightCamera = FlightCamera.fetch;
            Camera camera = flightCamera != null ? flightCamera.mainCamera : Camera.main;
            Vector3 eye = camera != null ? transform.InverseTransformPoint(camera.transform.position) : Vector3.back * visualRadius;

            Vector3 right = camera != null ? transform.InverseTransformDirection(camera.transform.right) : Vector3.right;
            Vector3 up = camera != null ? transform.InverseTransformDirection(camera.transform.up) : Vector3.up;
            glow.Draw(RenderFireball(), eye, right, up);
            if (inAtmosphere)
            {
                cloud.Draw(RenderAtmosphericCloud(0), eye);
                var manager = CameraManager.Instance;
                bool flightView = camera != null && manager != null && manager.currentCameraMode == CameraManager.CameraMode.Flight;
                shockFront.Draw(age, eye, flightView);
            }
        }

        private int RenderFireball()
        {
            float duration = inAtmosphere ? CloudHandoffEnd : VacuumDuration;
            if (age >= duration)
                return 0;

            float timeToPeak = inAtmosphere ? FireballPeakTime : 2.5f;
            float radius = FireballVisualRadius();
            float heat = Mathf.Clamp01((age - timeToPeak * 0.55f) / (duration - timeToPeak * 0.55f));
            float fade = 1f - Mathf.Clamp01((age - timeToPeak) / (duration - timeToPeak));
            float horizontal = radius;
            float vertical = radius;
            var center = Vector3.zero;
            if (inAtmosphere)
            {
                float handoff = FireballToCloudBlend();
                CloudCap cap = GetCloudCap();
                center = Vector3.up * FireballCenterHeight(radius, cap.CenterHeight, handoff);
                heat = FireballCooling();
                horizontal = Mathf.Lerp(radius, cap.Radius * 0.93f, handoff);
                vertical = Mathf.Lerp(radius, cap.Radius * 0.36f, handoff);
                fade = 1f - handoff;
            }

            // The halo gathers into the same volume as the growing smoke cap.
            var outerGlow = Color.Lerp(new Color(1f, 0.92f, 0.69f), new Color(0.82f, 0.30f, 0.14f), heat);
            outerGlow.a = fade * 0.92f;
            glow.SetFlare(0, center, 2f * Mathf.Sqrt(horizontal * vertical), outerGlow, 0f);

            Color color = Color.Lerp(new Color(1f, 0.99f, 0.91f), new Color(0.70f, 0.29f, 0.13f), heat);
            color.a = fade;
            for (int i = 1; i < FirePuffs; i++)
            {
                Vector4 puff = distribution[i];
                float spread = horizontal * puff.w * 0.53f;
                float rotation = age * (0.37f + 0.14f * puff.w);
                float sine = Mathf.Sin(rotation);
                float cosine = Mathf.Cos(rotation);
                float drift = 1f + 0.16f * Mathf.Sin(age * 1.15f + puff.y * Mathf.PI * 2f);
                var offset = new Vector3((puff.x * cosine - puff.z * sine) * spread * drift,
                    (puff.y - 0.5f) * vertical * 0.6f,
                    (puff.x * sine + puff.z * cosine) * spread * drift);
                glow.SetFlare(i, center + offset, vertical * (0.36f + 0.35f * puff.y), color, puff.w * 360f);
            }

            return FirePuffs;
        }

        private int RenderAtmosphericCloud(int count)
        {
            float density = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01((age - 8f) / 10f))
                * (1f - Mathf.Clamp01((age - 44f) / (AtmosphereDuration - 44f)));
            if (density <= 0f)
                return count;

            CloudCap cap = GetCloudCap();
            float top = cap.Top;
            float capRadius = cap.Radius;
            float capDepth = cap.Depth;
            float capBase = top - capDepth;
            float flowTime = Mathf.Max(0f, age - 5f);
            float dustDensity = density * (1f - Mathf.Clamp01((age - 20f) / 20f));
            float outwardSpread = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01((age - CloudHandoffEnd) / 21f));
            Color columnShadow = new Color(0.26f, 0.19f, 0.16f);
            Color columnLight = new Color(0.60f, 0.46f, 0.36f);
            Color capShadow = new Color(0.33f, 0.36f, 0.42f);
            Color capLight = new Color(0.93f, 0.89f, 0.79f);
            var undersideColor = new Color(0.90f, 0.65f, 0.35f);
            float ember = 1f - Mathf.SmoothStep(0f, 1f, Mathf.Clamp01((age - 8f) / 13f));
            var emberLight = new Color(0.95f, 0.52f, 0.27f);

            for (int i = 0; i < ColumnPuffs; i++)
            {
                Vector4 puff = distribution[FirePuffs + i];
                float level = Mathf.Repeat((i + 0.5f) / ColumnPuffs + flowTime * (0.027f + 0.012f * puff.w), 1f);
                float angle = Mathf.Atan2(puff.z, puff.x) + level * 2.2f + flowTime * 0.12f;
                float baseFlare = (1f - level) * (1f - level);
                float shoulderFlare = level * level * level;
                float flare = 0.24f + 0.22f * baseFlare + 0.14f * shoulderFlare;
                float spread = capRadius * flare * (0.35f + 0.65f * puff.w);
                float shear = capRadius * 0.10f * level * (Mathf.Sin(level * 8f - flowTime * 0.30f) + 1f);
                var position = new Vector3(Mathf.Cos(angle) * spread + shear, capBase * level, Mathf.Sin(angle) * spread);
                float blend = Mathf.Clamp01(0.25f + level * 0.42f + Mathf.Cos(angle) * 0.23f);
                Color color = Color.Lerp(columnShadow, columnLight, blend);
                color.a = density * (0.60f + 0.26f * Mathf.Sin(level * Mathf.PI));
                float size = capRadius * (0.28f + 0.18f * puff.y + 0.10f * baseFlare + 0.08f * shoulderFlare);
                WritePuff(count++, position, size, color, puff.w * 360f + flowTime * 8f);
            }

            // Inner smoke rises and rolls down around the outside of the cap.
            for (int i = 0; i < CapPuffs; i++)
            {
                Vector4 puff = distribution[FirePuffs + ColumnPuffs + i];
                float azimuth = Mathf.Atan2(puff.z, puff.x) + flowTime * (0.024f + 0.022f * puff.y);
                float roll = puff.y * 2f * Mathf.PI - flowTime * (0.30f + 0.10f * puff.w);
                float lobe = 0.90f + 0.10f * Mathf.Sin(azimuth * 5f + flowTime * 0.15f);
                float rollHeight = Mathf.Sin(roll);
                float ringFraction = 0.48f + (0.19f + 0.20f * puff.w) * Mathf.Cos(roll);
                float rim = Mathf.Clamp01(ringFraction / 0.87f);
                float ring = capRadius * lobe * ringFraction * (1f + 0.95f * outwardSpread * rim);
                float droop = 0.14f * outwardSpread * rim * rim;
                float height = capBase + capDepth * (0.50f + 0.39f * rollHeight - droop);
                float size = capDepth * (0.29f + 0.43f * puff.w) * (1f + 0.12f * outwardSpread);
                height = Mathf.Min(height, top - size * 0.5f);
                var position = new Vector3(Mathf.Cos(azimuth) * ring, height, Mathf.Sin(azimuth) * ring);
                float light = Mathf.Clamp01(0.49f + rollHeight * 0.33f + Mathf.Cos(azimuth) * 0.18f);
                Color color = Color.Lerp(capShadow, capLight, light);
                float underlighting = Mathf.Clamp01(-rollHeight) * (0.56f + 0.22f * puff.w);
                color = Color.Lerp(color, undersideColor, underlighting);
                color = Color.Lerp(color, emberLight, ember * (0.68f - 0.28f * light));
                color.a = density * (0.50f + 0.32f * puff.w);
                WritePuff(count++, position, size, color, puff.w * 360f + flowTime * 15f);
            }

            // Fill the space above the rolling rim with a rounded, shaded crown.
            float crownDensity = density * Mathf.Clamp01((age - 10f) / 9f);
            float crownRadius = capRadius * (0.64f + 0.69f * outwardSpread);
            for (int i = 0; i < CrownPuffs && crownDensity > 0f; i++)
            {
                Vector4 puff = distribution[FirePuffs + ColumnPuffs + CapPuffs + i];
                float fraction = Mathf.Sqrt(puff.w);
                float angle = Mathf.Atan2(puff.z, puff.x) + flowTime * 0.025f;
                float spread = crownRadius * fraction;
                float size = capDepth * (0.42f + 0.40f * puff.y);
                float height = top - size * 0.5f - capDepth * (0.38f * fraction * fraction + 0.09f * (1f - puff.y));
                var position = new Vector3(Mathf.Cos(angle) * spread, height, Mathf.Sin(angle) * spread);
                float light = Mathf.Clamp01(0.38f + 0.34f * puff.y + 0.28f * Mathf.Cos(angle));
                Color color = Color.Lerp(capShadow, capLight, light);
                color.a = crownDensity * (0.48f + 0.22f * puff.y);
                WritePuff(count++, position, size, color, puff.y * 360f + flowTime * 6f);
            }

            for (int i = 0; i < DustPuffs && dustDensity > 0f; i++)
            {
                Vector4 puff = distribution[FirePuffs + ColumnPuffs + CapPuffs + CrownPuffs + i];
                float spread = capRadius * (0.30f + 0.64f * puff.w);
                float height = capRadius * (0.045f + 0.10f * puff.y);
                var position = new Vector3(puff.x * spread, height, puff.z * spread);
                var color = new Color(0.46f, 0.38f, 0.31f, dustDensity * (0.24f + 0.30f * puff.w));
                WritePuff(count++, position, capRadius * (0.17f + 0.21f * puff.y), color, puff.y * 360f);
            }

            return count;
        }

        private void WritePuff(int index, Vector3 position, float size, Color color, float rotation)
        {
            cloud.SetBillow(index, position, size, color, rotation);
        }

        private void OnDestroy()
        {
            if (fireballMesh != null)
                Destroy(fireballMesh);
            if (fireballTexture != null)
                Destroy(fireballTexture);
            if (fireballMaterial != null)
                Destroy(fireballMaterial);
            if (cloud != null)
                cloud.Release();
            if (glow != null)
                glow.Release();
            if (glowMaterial != null)
                Destroy(glowMaterial);
            if (glowTexture != null)
                Destroy(glowTexture);
            if (cloudMaterial != null)
                Destroy(cloudMaterial);
            if (shockFront != null)
                shockFront.Release();
        }
    }
}
